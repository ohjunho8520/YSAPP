package com.example.myapplication.schedule;

import android.app.DatePickerDialog;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.Calendar;

public class AddScheduleActivity extends AppCompatActivity {
    private EditText etTitle;
    private TextView tvStartDate, tvEndDate;
    private RadioGroup radioColorGroup;
    private Button btnSave;

    private MyCalendarDay startDate, endDate;
    private String selectedColor = COLOR_CHOICES[0];

    private static final String[] COLOR_CHOICES = {
            "#F44336", "#E91E63", "#9C27B0", "#3F51B5", "#2196F3",
            "#00BCD4", "#4CAF50", "#FFEB3B", "#FF9800", "#795548"
    };

    private FirebaseUser user;
    private FirebaseFirestore db;
    private UserSchedule editingSchedule;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_schedule);

        etTitle = findViewById(R.id.etTitle);
        tvStartDate = findViewById(R.id.tvStartDate);
        tvEndDate = findViewById(R.id.tvEndDate);
        radioColorGroup = findViewById(R.id.radioColorGroup);
        btnSave = findViewById(R.id.btnSave);

        db = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();

        tvStartDate.setOnClickListener(v -> openDatePicker(true));
        tvEndDate.setOnClickListener(v -> openDatePicker(false));

        // 색상 라디오버튼 동적생성
        radioColorGroup.removeAllViews();
        for (int i = 0; i < COLOR_CHOICES.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(i + 1);
            rb.setButtonDrawable(null); // 체크 아이콘 감춤
            rb.setBackgroundResource(R.drawable.selector_color_circle); // selector(테두리) 적용
            rb.setText("");
            rb.setWidth(80);
            rb.setHeight(80);
            // ✅ 색상 채우기!
            rb.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(COLOR_CHOICES[i])));
            if (i == 0) rb.setChecked(true);
            radioColorGroup.addView(rb);
        }


        radioColorGroup.setOnCheckedChangeListener((group, checkedId) -> {
            int idx = checkedId - 1;
            if (idx >= 0 && idx < COLOR_CHOICES.length)
                selectedColor = COLOR_CHOICES[idx];
        });

        // 수정모드
        editingSchedule = (UserSchedule) getIntent().getSerializableExtra("editSchedule");
        if (editingSchedule != null) {
            etTitle.setText(editingSchedule.getTitle());
            startDate = editingSchedule.getStartDate();
            endDate = editingSchedule.getEndDate();
            tvStartDate.setText(startDate.getYear() + "/" + startDate.getMonth() + "/" + startDate.getDay());
            tvEndDate.setText(endDate.getYear() + "/" + endDate.getMonth() + "/" + endDate.getDay());
            selectedColor = editingSchedule.getColor();
            for (int i = 0; i < COLOR_CHOICES.length; i++) {
                if (COLOR_CHOICES[i].equals(selectedColor)) {
                    radioColorGroup.check(i + 1);
                    break;
                }
            }
        }

        btnSave.setOnClickListener(v -> saveSchedule());
    }

    private void openDatePicker(boolean isStart) {
        final Calendar cal = Calendar.getInstance();
        DatePickerDialog dlg = new DatePickerDialog(this, (view, y, m, d) -> {
            MyCalendarDay picked = new MyCalendarDay(y, m + 1, d);
            if (isStart) {
                startDate = picked;
                tvStartDate.setText(y + "/" + (m + 1) + "/" + d);
            } else {
                endDate = picked;
                tvEndDate.setText(y + "/" + (m + 1) + "/" + d);
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private void saveSchedule() {
        String title = etTitle.getText().toString().trim();
        if (title.isEmpty() || startDate == null || endDate == null) {
            Toast.makeText(this, "제목, 시작, 종료 날짜를 모두 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (user == null) {
            Toast.makeText(this, "로그인 후 이용해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        String uid = user.getUid();
        UserSchedule schedule = new UserSchedule(uid, title, startDate, endDate, selectedColor);

        if (editingSchedule != null && editingSchedule.getDocId() != null) {
            db.collection("schoolData")
                    .document("schoolInfo")
                    .collection("schedule")
                    .document(editingSchedule.getDocId())
                    .set(schedule)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "일정이 수정되었습니다.", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "수정 실패: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        } else {
            db.collection("schoolData")
                    .document("schoolInfo")
                    .collection("schedule")
                    .add(schedule)
                    .addOnSuccessListener(documentReference -> {
                        Toast.makeText(this, "일정이 등록되었습니다.", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "저장 실패: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }
}
