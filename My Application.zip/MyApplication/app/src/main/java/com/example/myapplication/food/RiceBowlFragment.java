package com.example.myapplication.food;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;

import java.util.Random;

public class RiceBowlFragment extends Fragment {

    private Button btnPickMenu;
    private ImageView resultImage;
    private TextView resultText;

    private final String[] menuIds = {
            "rice_1", "rice_2", "rice_3", "rice_4", "rice_5", "rice_6", "rice_7"
    };

    private final String[] menuNames = {
            "제육덮밥", "닭갈비잡채밥", "치킨마요", "마그마치킨마요", "참치마요", "마그마참치마요", "육회비빔밥"
    };

    private final int[] menuImages = {
            R.drawable.jeyuk,
            R.drawable.dakgalbi,
            R.drawable.chickenmayo,
            R.drawable.magma_chicken,
            R.drawable.tunamayo,
            R.drawable.magma_tuna,
            R.drawable.yukhwe
    };

    public RiceBowlFragment() {
        super(R.layout.fragment_ricebowl);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnPickMenu = view.findViewById(R.id.btnPickMenu);
        resultImage = view.findViewById(R.id.resultImage);
        resultText = view.findViewById(R.id.resultText);

        btnPickMenu.setOnClickListener(v -> {
            Random random = new Random();
            int index = random.nextInt(menuNames.length);

            RotateAnimation rotate = new RotateAnimation(
                    0, 720,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f);
            rotate.setDuration(1000);
            rotate.setFillAfter(true);
            resultImage.startAnimation(rotate);

            new Handler().postDelayed(() -> {
                resultImage.setImageResource(menuImages[index]);
                resultText.setText("오늘의 추천: " + menuNames[index]);

                resultImage.setVisibility(View.VISIBLE);
                resultText.setVisibility(View.VISIBLE);

                View.OnClickListener goToDetail = vv -> {
                    Intent intent = new Intent(requireContext(), MenuDetailActivity.class);
                    intent.putExtra("menuId", menuIds[index]);
                    intent.putExtra("menuName", menuNames[index]);
                    intent.putExtra("menuImageResId", menuImages[index]);
                    startActivity(intent);
                };
                resultImage.setOnClickListener(goToDetail);
                resultText.setOnClickListener(goToDetail);
            }, 1000);
        });

        // 메뉴 클릭 → 상세 화면 이동
        setupClick(view, R.id.menu_soulfood, "rice_1", "제육덮밥", R.drawable.jeyuk);
        setupClick(view, R.id.menu_chicken_jobchabob, "rice_2", "닭갈비잡채밥", R.drawable.dakgalbi);
        setupClick(view, R.id.menu_chicken_mayo, "rice_3", "치킨마요", R.drawable.chickenmayo);
        setupClick(view, R.id.menu_fire_chicken_mayo, "rice_4", "마그마치킨마요", R.drawable.magma_chicken);
        setupClick(view, R.id.menu_chamchi_mayo, "rice_5", "참치마요", R.drawable.tunamayo);
        setupClick(view, R.id.menu_fire_chamchi_mayo, "rice_6", "마그마참치마요", R.drawable.magma_tuna);
        setupClick(view, R.id.menu_yuk_bibimbab, "rice_7", "육회비빔밥", R.drawable.yukhwe);
    }

    private void setupClick(View view, int layoutId, String menuId, String menuName, int imageResId) {
        LinearLayout layout = view.findViewById(layoutId);
        if (layout != null) layout.setOnClickListener(v -> {
            Intent intent = new Intent(requireContext(), MenuDetailActivity.class);
            intent.putExtra("menuId", menuId);
            intent.putExtra("menuName", menuName);
            intent.putExtra("menuImageResId", imageResId);
            startActivity(intent);
        });
    }
}
