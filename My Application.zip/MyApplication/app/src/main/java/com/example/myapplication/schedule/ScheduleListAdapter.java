package com.example.myapplication.schedule;

import android.app.AlertDialog;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.R;
import java.util.List;

public class ScheduleListAdapter extends RecyclerView.Adapter<ScheduleListAdapter.ViewHolder> {
    private List<UserSchedule> schedules;
    private OnScheduleActionListener listener;

    public interface OnScheduleActionListener {
        void onEdit(UserSchedule schedule);
        void onDelete(UserSchedule schedule);
    }

    public ScheduleListAdapter(List<UserSchedule> schedules, OnScheduleActionListener listener) {
        this.schedules = schedules;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_schedule, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int pos) {
        UserSchedule schedule = schedules.get(pos);

        // 제목
        holder.tvTitle.setText(schedule.getTitle());

        // 기간: 시작/끝이 다르면 ~표기, 같으면 하루만
        String start = schedule.getStartDate() != null ? schedule.getStartDate().format("yyyy.MM.dd") : "";
        String end = schedule.getEndDate() != null ? schedule.getEndDate().format("yyyy.MM.dd") : "";
        String periodText = start.equals(end) ? start : (start + " ~ " + end);
        holder.tvPeriod.setText(periodText);

        // 색상바
        try {
            holder.viewColor.setBackgroundColor(Color.parseColor(schedule.getColor()));
        } catch (Exception e) {
            holder.viewColor.setBackgroundColor(Color.LTGRAY);
        }

        // 하드코딩 학사일정이면 버튼 숨김
        boolean isFixed = schedule.getUid() != null && schedule.getUid().equals("all");
        if (isFixed) {
            holder.btnEdit.setVisibility(View.GONE);
            holder.btnDelete.setVisibility(View.GONE);
        } else {
            holder.btnEdit.setVisibility(View.VISIBLE);
            holder.btnDelete.setVisibility(View.VISIBLE);
        }

        // 수정/삭제
        holder.btnEdit.setOnClickListener(v -> {
            if (!isFixed && listener != null) listener.onEdit(schedule);
        });
        holder.btnDelete.setOnClickListener(v -> {
            if (!isFixed && listener != null) {
                new AlertDialog.Builder(v.getContext())
                        .setTitle("일정 삭제")
                        .setMessage("정말로 이 일정을 삭제하시겠습니까?")
                        .setPositiveButton("삭제", (dialog, which) -> listener.onDelete(schedule))
                        .setNegativeButton("취소", null)
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return schedules.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View viewColor;
        TextView tvTitle, tvPeriod;
        ImageButton btnEdit, btnDelete;

        ViewHolder(@NonNull View v) {
            super(v);
            viewColor = v.findViewById(R.id.viewColor);
            tvTitle = v.findViewById(R.id.tvTitle);
            tvPeriod = v.findViewById(R.id.tvPeriod);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
