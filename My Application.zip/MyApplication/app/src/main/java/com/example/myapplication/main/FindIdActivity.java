package com.example.myapplication.main;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.google.firebase.firestore.FirebaseFirestore;

public class FindIdActivity extends AppCompatActivity {
    private EditText editFindName, editFindPhone;
    private Button btnFindId;
    private TextView txtFoundStudentId;
    private FirebaseFirestore db;
    private String rootDoc = "schoolInfo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_id);

        editFindName = findViewById(R.id.editFindName);
        editFindPhone = findViewById(R.id.editFindPhone);
        btnFindId = findViewById(R.id.btnFindId);
        txtFoundStudentId = findViewById(R.id.txtFoundStudentId);

        db = FirebaseFirestore.getInstance();

        btnFindId.setOnClickListener(v -> {
            String name = editFindName.getText().toString().trim();
            String phone = editFindPhone.getText().toString().trim();

            if (name.isEmpty() || phone.isEmpty()) {
                txtFoundStudentId.setText("이름과 전화번호를 모두 입력하세요.");
                return;
            }
            db.collection("schoolData").document(rootDoc)
                    .collection("users")
                    .whereEqualTo("name", name)
                    .whereEqualTo("phone", phone)
                    .get()
                    .addOnSuccessListener(queryDocumentSnapshots -> {
                        if (!queryDocumentSnapshots.isEmpty()) {
                            String studentId = queryDocumentSnapshots.getDocuments().get(0).getId();
                            txtFoundStudentId.setText("학번: " + studentId);
                        } else {
                            txtFoundStudentId.setText("일치하는 학번이 없습니다.");
                        }
                    })
                    .addOnFailureListener(e -> {
                        txtFoundStudentId.setText("네트워크 오류");
                    });
        });
    }
}
