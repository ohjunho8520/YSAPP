package com.example.myapplication.schedule;

import java.io.Serializable;

public class UserSchedule implements Serializable {
    private String uid;
    private String title;
    private MyCalendarDay startDate;
    private MyCalendarDay endDate;
    private String color;
    private String docId;

    public UserSchedule() {}

    public UserSchedule(String uid, String title, MyCalendarDay startDate, MyCalendarDay endDate, String color) {
        this.uid = uid;
        this.title = title;
        this.startDate = startDate;
        this.endDate = endDate;
        this.color = color;
    }

    public String getUid() { return uid; }
    public void setUid(String uid) { this.uid = uid; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public MyCalendarDay getStartDate() { return startDate; }
    public void setStartDate(MyCalendarDay startDate) { this.startDate = startDate; }
    public MyCalendarDay getEndDate() { return endDate; }
    public void setEndDate(MyCalendarDay endDate) { this.endDate = endDate; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public String getDocId() { return docId; }
    public void setDocId(String docId) { this.docId = docId; }
}
