package com.example.myapplication.shuttle;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class ShuttleMokdongActivity extends AppCompatActivity {

    private LinearLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shuttle_canvas_mokdong);;

        container = findViewById(R.id.shuttleItemContainer);

        addShuttleItem("8:00", "서울남부법원", "서울남부지방법원 버스정류장");
        addShuttleItem("8:02", "진명여고", "진명여고");
        addShuttleItem("8:05", "목동역", "목동역 5번출구");
        addShuttleItem("8:10", "오목교역", "오목교역 5번출구");
        addShuttleItem("9:05", "안양역(경유)", "안양역 경유");
        addShuttleItem("9:15", "연성대학교", "연성대학교 정문");
    }



    private void addShuttleItem(String time, String station, String desc) {
        View itemView = LayoutInflater.from(this).inflate(R.layout.item_shuttle, container, false);

        TextView tvTime = itemView.findViewById(R.id.time);
        TextView tvStation = itemView.findViewById(R.id.station);
        TextView tvDesc = itemView.findViewById(R.id.desc);

        tvTime.setText(time);
        tvStation.setText(station);
        tvDesc.setText(desc);

        container.addView(itemView);
    }
}
