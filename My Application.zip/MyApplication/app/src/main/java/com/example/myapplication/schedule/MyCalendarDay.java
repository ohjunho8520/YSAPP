package com.example.myapplication.schedule;

import java.io.Serializable;

public class MyCalendarDay implements Serializable {
    private int year, month, day;

    public MyCalendarDay() {}
    public MyCalendarDay(int year, int month, int day) {
        this.year = year; this.month = month; this.day = day;
    }
    public static MyCalendarDay from(int year, int month, int day) {
        return new MyCalendarDay(year, month, day);
    }
    public int getYear() { return year; }
    public int getMonth() { return month; }
    public int getDay() { return day; }
    public boolean isBefore(MyCalendarDay other) {
        if (year != other.year) return year < other.year;
        if (month != other.month) return month < other.month;
        return day < other.day;
    }
    public boolean isAfter(MyCalendarDay other) {
        if (year != other.year) return year > other.year;
        if (month != other.month) return month > other.month;
        return day > other.day;
    }
    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof MyCalendarDay)) return false;
        MyCalendarDay d = (MyCalendarDay)obj;
        return this.year == d.year && this.month == d.month && this.day == d.day;
    }

    // ⭐️ 날짜를 포맷(문자열)으로 반환하는 메서드 추가!
    public String format(String pattern) {
        String y = String.format("%04d", year);
        String m = String.format("%02d", month);
        String d = String.format("%02d", day);

        return pattern.replace("yyyy", y)
                .replace("MM", m)
                .replace("dd", d);
    }
}
