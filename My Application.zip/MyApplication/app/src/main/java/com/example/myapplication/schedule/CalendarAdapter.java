package com.example.myapplication.schedule;

import android.content.Context;
import android.graphics.Color;
import android.view.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.R;
import java.util.*;

public class CalendarAdapter extends RecyclerView.Adapter<CalendarAdapter.ViewHolder> {
    private List<CalendarDate> dateList;
    private OnDateClickListener listener;
    private List<UserSchedule> userSchedules;
    private List<UserSchedule> fixedSchedules;

    private MyCalendarDay selectedDay = null;

    public void setSelectedDay(MyCalendarDay day) {
        this.selectedDay = day;
        notifyDataSetChanged();
    }

    // ✅ 날짜 클릭 인터페이스 직접 선언
    public interface OnDateClickListener {
        void onDateClick(String day);
    }

    public CalendarAdapter(List<CalendarDate> dateList, OnDateClickListener listener, List<UserSchedule> userSchedules, List<UserSchedule> fixedSchedules) {
        this.dateList = dateList;
        this.listener = listener;
        this.userSchedules = userSchedules;
        this.fixedSchedules = fixedSchedules;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_calendar_date, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int pos) {
        CalendarDate calendarDate = dateList.get(pos);
        String dayStr = calendarDate.getDay();
        holder.tvDay.setText(dayStr);

        LinearLayout layoutColorBars = holder.layoutColorBars;
        layoutColorBars.removeAllViews();
        MyCalendarDay thisDay = calendarDate.getDate();
        if (thisDay == null || dayStr.isEmpty()) {
            holder.tvDay.setText("");
            layoutColorBars.setVisibility(View.INVISIBLE);
            holder.itemView.setOnClickListener(null);
            return;
        }
        layoutColorBars.setVisibility(View.VISIBLE);

        // 색상바 최대 3개까지 표시
        List<String> colors = new ArrayList<>();
        // 1. 사용자일정
        for (UserSchedule s : userSchedules) {
            if (isDateInRange(thisDay, s.getStartDate(), s.getEndDate()) && colors.size() < 3) {
                colors.add(s.getColor());
            }
        }
        // 2. 학사일정(공통)
        for (UserSchedule s : fixedSchedules) {
            if (isDateInRange(thisDay, s.getStartDate(), s.getEndDate()) && colors.size() < 3) {
                colors.add(s.getColor());
            }
        }
        for (String color : colors) {
            View bar = new View(holder.itemView.getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            params.setMargins(2, 0, 2, 0);
            bar.setLayoutParams(params);
            try {
                bar.setBackgroundColor(Color.parseColor(color));
            } catch (Exception e) {
                bar.setBackgroundColor(Color.LTGRAY);
            }
            layoutColorBars.addView(bar);
        }

        // ★ 요일별 색상 적용 (토=파랑, 일=빨강, 평일=검정)
        if (!dayStr.isEmpty()) {
            int column = pos % 7;
            if (column == 0) { // 일요일
                holder.tvDay.setTextColor(Color.parseColor("#FF2222")); // 빨강
            } else if (column == 6) { // 토요일
                holder.tvDay.setTextColor(Color.parseColor("#2962FF")); // 파랑
            } else {
                holder.tvDay.setTextColor(Color.parseColor("#222222")); // 평일 검정
            }
        } else {
            holder.tvDay.setTextColor(Color.parseColor("#222222"));
        }

        // ★ 선택 표시
        if (calendarDate.getDate() != null && selectedDay != null && calendarDate.getDate().equals(selectedDay)) {
            // 배경색 or 테두리
            holder.itemView.setBackgroundResource(R.drawable.bg_selected_day); // 예시
        } else {
            holder.itemView.setBackgroundResource(0); // 배경 초기화
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onDateClick(dayStr);
        });
    }

    @Override
    public int getItemCount() { return dateList.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDay;
        LinearLayout layoutColorBars;
        ViewHolder(@NonNull View v) {
            super(v);
            tvDay = v.findViewById(R.id.tvDay);
            layoutColorBars = v.findViewById(R.id.layoutColorBars);
        }
    }

    private boolean isDateInRange(MyCalendarDay d, MyCalendarDay start, MyCalendarDay end) {
        if (start == null || end == null || d == null) return false;
        return (!d.isBefore(start) && !d.isAfter(end));
    }
}
