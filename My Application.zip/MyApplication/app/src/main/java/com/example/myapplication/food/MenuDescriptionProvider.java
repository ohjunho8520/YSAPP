package com.example.myapplication.food; // ← 자신의 패키지 경로에 맞게 수정

import java.util.HashMap;
import java.util.Map;

public class MenuDescriptionProvider {

    private static final Map<String, String> descriptions = new HashMap<>();

    static {
        descriptions.put("함박카레동", "부드러운 함박스테이크와 진한 카레가 어우러진 든든한 한 끼");
        descriptions.put("치킨치즈카레동", "바삭한 치킨 위에 고소한 치즈, 깊은 풍미의 카레를 더한 메뉴");
        descriptions.put("치킨가라아게카레동", "일본식 치킨 가라아게와 카레의 이색 조화");
        descriptions.put("대왕소시지카레동", "큼직한 소시지와 풍부한 카레 소스가 만난 푸짐한 한 접시");
        descriptions.put("오므라이스", "부드러운 달걀과 볶음밥이 어우러진 기본 중의 기본");
        descriptions.put("카레오므라이스", "오므라이스에 진한 카레를 더한 매콤달콤한 맛");
        descriptions.put("함박오므라이스", "함박스테이크와 오므라이스의 환상 궁합");
        descriptions.put("닭강정오므라이스", "달콤한 닭강정과 부드러운 계란밥의 꿀조합");
        descriptions.put("치킨치즈오므라이스", "바삭한 치킨과 고소한 치즈가 계란밥과 만났다!");
        descriptions.put("대왕소시지오므라이스", "큼직한 소시지로 식감도 맛도 UP!");
        descriptions.put("치즈김치가츠동", "김치가츠동 위에 녹아든 치즈로 풍미 가득");
        descriptions.put("세종대왕돈까스", "압도적인 크기의 돈까스로 왕처럼 즐기는 한 끼");
        descriptions.put("고구마치즈돈까스", "달콤한 고구마와 치즈가 어우러진 색다른 돈까스");
        descriptions.put("소떡소떡", "소시지와 떡이 번갈아 꽂힌 인기 간식 메뉴");
        descriptions.put("닭강정", "달콤 짭조름한 양념이 입맛을 사로잡는 국민 치킨");
        descriptions.put("치즈시즈닝치킨", "치킨 위에 치즈 시즈닝을 뿌려 풍미를 더한 메뉴");
        descriptions.put("계란라면", "반숙 계란이 올라간 따끈한 라면 한 그릇");
        descriptions.put("냉모밀", "시원한 국물과 쫄깃한 면발, 여름철 필수 메뉴");
        descriptions.put("새우튀김냉모밀", "바삭한 새우튀김을 곁들인 고급 냉모밀");
        descriptions.put("돈까스정식(돈까스, 냉모밀)", "돈까스와 냉모밀을 한 번에 즐기는 인기 정식 세트");
        descriptions.put("돼지고기 김치찌개", "푹 익은 김치와 고기가 어우러진 얼큰한 찌개");
        descriptions.put("고기전병", "촉촉한 고기소를 전병에 감싼 전통 간식");
        descriptions.put("제육덮밥", "매콤한 제육볶음이 듬뿍 올라간 한 그릇 요리");
        descriptions.put("닭갈비잡채밥", "달콤한 닭갈비와 부드러운 잡채가 어우러진 메뉴");
        descriptions.put("치킨마요", "고소한 마요와 간장소스가 어우러진 간편 덮밥");
        descriptions.put("마그마치킨마요", "화끈한 매운 소스가 포인트인 마요치킨 덮밥");
        descriptions.put("참치마요", "담백한 참치와 마요네즈가 어우러진 기본 덮밥");
        descriptions.put("마그마참치마요", "매콤하게 즐기는 참치마요의 변신");
        descriptions.put("육회비빔밥", "신선한 육회와 특제 양념이 어우러진 고급 비빔밥");
    }

    public static String getDescription(String menuName) {
        return descriptions.getOrDefault(menuName, "맛있는 메뉴입니다.");
    }
}
