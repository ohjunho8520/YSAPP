package com.example.myapplication.schedule;

public class CalendarDate {
    private String day;
    private int count;
    private MyCalendarDay date;

    public CalendarDate(String day, int count, MyCalendarDay date) {
        this.day = day;
        this.count = count;
        this.date = date;
    }

    public String getDay() { return day; }
    public int getCount() { return count; }
    public MyCalendarDay getDate() { return date; }
}
