package com.example.myapplication.food;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.List;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ViewHolder> {

    private List<Review> reviewList;
    private String currentUserId; // 로그인된 유저 학번
    private OnReviewListener listener;

    public interface OnReviewListener {
        void onEdit(Review review);
        void onDelete(Review review);
    }

    public ReviewAdapter(List<Review> reviewList, String currentUserId, OnReviewListener listener) {
        this.reviewList = reviewList;
        this.currentUserId = currentUserId;
        this.listener = listener;
    }

    public void setReviewList(List<Review> reviewList) {
        this.reviewList = reviewList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comment, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Review review = reviewList.get(position);
        holder.tvName.setText(review.getName());
        holder.tvRating.setText("★ " + review.getRating());
        holder.tvComment.setText(review.getComment());
        holder.tvDate.setText(review.getDate());

        // 본인 리뷰만 수정/삭제 버튼 노출
        if (currentUserId != null && currentUserId.equals(review.getUserId())) {
            holder.btnContainer.setVisibility(View.VISIBLE);
        } else {
            holder.btnContainer.setVisibility(View.GONE);
        }

        holder.btnEdit.setOnClickListener(v -> listener.onEdit(review));
        holder.btnDelete.setOnClickListener(v -> listener.onDelete(review));
    }

    @Override
    public int getItemCount() {
        return reviewList == null ? 0 : reviewList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvRating, tvComment, tvDate;
        LinearLayout btnContainer;
        Button btnEdit, btnDelete;

        ViewHolder(View v) {
            super(v);
            tvName = v.findViewById(R.id.tvName);
            tvRating = v.findViewById(R.id.tvRating);
            tvComment = v.findViewById(R.id.tvComment);
            tvDate = v.findViewById(R.id.tvDate);
            btnContainer = v.findViewById(R.id.btnContainer);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
