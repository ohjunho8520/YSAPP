package com.example.myapplication.food;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;

import java.text.SimpleDateFormat;
import java.util.*;

public class MenuDetailActivity extends AppCompatActivity {
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private ReviewAdapter adapter;
    private List<Review> reviewList = new ArrayList<>();
    private String menuId, menuName;
    private int menuImageResId;

    private String userId = null;
    private String userName = null;

    private TextView tvMenuName, tvMenuDescription;
    private ImageView ivMenuPhoto;
    private EditText editComment;
    private Button btnSaveComment;
    private RatingBar ratingBar;
    private RecyclerView recyclerView;

    private final String ROOT_DOC = "schoolInfo";
    private ListenerRegistration reviewListener;

    private ReviewAdapter.OnReviewListener reviewListenerObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.myapplication.R.layout.activity_menu_detail);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        userId = null;
        userName = null;

        // 1. 메뉴 정보 받기 (정확하게 보내야 함)
        menuId = getIntent().getStringExtra("menuId");
        menuName = getIntent().getStringExtra("menuName");
        menuImageResId = getIntent().getIntExtra("menuImageResId", com.example.myapplication.R.drawable.a_1);

        // 2. UI 요소 연결
        tvMenuName = findViewById(com.example.myapplication.R.id.tvMenuName);
        ivMenuPhoto = findViewById(com.example.myapplication.R.id.ivMenuPhoto);
        tvMenuDescription = findViewById(com.example.myapplication.R.id.tvMenuDescription);
        editComment = findViewById(com.example.myapplication.R.id.editComment);
        btnSaveComment = findViewById(com.example.myapplication.R.id.btnSaveComment);
        ratingBar = findViewById(com.example.myapplication.R.id.ratingBar);
        recyclerView = findViewById(R.id.commentRecyclerView);

        // 3. UI에 데이터 세팅
        tvMenuName.setText(menuName);
        ivMenuPhoto.setImageResource(menuImageResId);
        tvMenuDescription.setText(MenuDescriptionProvider.getDescription(menuName));

        // 4. 리뷰 리스너 설정
        reviewListenerObj = new ReviewAdapter.OnReviewListener() {
            @Override
            public void onEdit(Review review) {
                editComment.setText(review.getComment());
                ratingBar.setRating(review.getRating());
                btnSaveComment.setText("수정 완료");
                btnSaveComment.setTag(review.getId());
            }

            @Override
            public void onDelete(Review review) {
                new AlertDialog.Builder(MenuDetailActivity.this)
                        .setTitle("리뷰 삭제")
                        .setMessage("정말 삭제하시겠습니까?")
                        .setPositiveButton("삭제", (dialog, which) -> {
                            db.collection("schoolData").document(ROOT_DOC)
                                    .collection("reviews").document(menuId)
                                    .collection("reviewList").document(review.getId())
                                    .delete()
                                    .addOnFailureListener(e -> Toast.makeText(MenuDetailActivity.this, "리뷰 삭제 실패", Toast.LENGTH_SHORT).show());
                        })
                        .setNegativeButton("취소", null)
                        .show();
            }

        };

        // 5. RecyclerView 설정
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ReviewAdapter(reviewList, userId, reviewListenerObj);
        recyclerView.setAdapter(adapter);

        // 6. 리뷰 실시간 로딩
        setupReviewListener();

        // 7. 댓글 등록 버튼
        btnSaveComment.setOnClickListener(v -> {
            FirebaseUser curUser = mAuth.getCurrentUser();
            if (curUser == null) {
                Toast.makeText(this, "로그인 후 이용 가능합니다.", Toast.LENGTH_SHORT).show();
                return;
            }

            db.collection("schoolData").document(ROOT_DOC)
                    .collection("users")
                    .whereEqualTo("email", curUser.getEmail())
                    .get()
                    .addOnSuccessListener(qs -> {
                        if (!qs.isEmpty()) {
                            String curName = qs.getDocuments().get(0).getString("name");

                            String comment = editComment.getText().toString().trim();
                            int rating = (int) ratingBar.getRating();
                            if (TextUtils.isEmpty(comment)) {
                                Toast.makeText(this, "댓글을 입력하세요.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            if (rating < 1) {
                                Toast.makeText(this, "별점을 선택하세요.", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            String reviewId = (btnSaveComment.getTag() != null)
                                    ? btnSaveComment.getTag().toString()
                                    : db.collection("schoolData").document(ROOT_DOC)
                                    .collection("reviews").document(menuId)
                                    .collection("reviewList").document().getId();

                            String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
                            Review review = new Review(reviewId, curUser.getEmail(), curName, rating, comment, date);

                            db.collection("schoolData").document(ROOT_DOC)
                                    .collection("reviews").document(menuId)
                                    .collection("reviewList").document(reviewId)
                                    .set(review)
                                    .addOnSuccessListener(aVoid -> {
                                        editComment.setText("");
                                        ratingBar.setRating(0);
                                        btnSaveComment.setText("댓글 등록");
                                        btnSaveComment.setTag(null);
                                    })
                                    .addOnFailureListener(e -> Toast.makeText(MenuDetailActivity.this, "댓글 저장 실패", Toast.LENGTH_SHORT).show());
                        } else {
                            Toast.makeText(this, "로그인 정보가 올바르지 않습니다.", Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        FirebaseUser curUser = mAuth.getCurrentUser();
        if (curUser == null) {
            userId = null;
            userName = null;
        }
    }

    private void setupReviewListener() {
        reviewListener = db.collection("schoolData").document(ROOT_DOC)
                .collection("reviews").document(menuId)
                .collection("reviewList")
                .orderBy("date", Query.Direction.DESCENDING)
                .addSnapshotListener((querySnapshot, error) -> {
                    if (error != null) return;
                    reviewList.clear();
                    if (querySnapshot != null) {
                        for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                            Review review = doc.toObject(Review.class);
                            if (review != null) reviewList.add(review);
                        }
                    }
                    FirebaseUser curUser = mAuth.getCurrentUser();
                    String currentId = (curUser != null && curUser.getEmail() != null) ? curUser.getEmail() : null;
                    adapter = new ReviewAdapter(reviewList, currentId, reviewListenerObj);
                    recyclerView.setAdapter(adapter);
                });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (reviewListener != null) reviewListener.remove();
    }
}
