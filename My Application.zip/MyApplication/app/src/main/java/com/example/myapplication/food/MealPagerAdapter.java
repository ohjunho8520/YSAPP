package com.example.myapplication.food;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class MealPagerAdapter extends FragmentStateAdapter {

    public MealPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0:
                return new NoodleFragment();
            case 1:
                return new RiceBowlFragment();
            case 2:
                return new DonkatsuFragment();
            default:
                return new NoodleFragment();
        }
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
