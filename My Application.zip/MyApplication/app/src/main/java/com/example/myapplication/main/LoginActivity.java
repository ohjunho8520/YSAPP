package com.example.myapplication.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private EditText editStudentId, editPassword;
    private Button btnLogin, btnJoin, btnFindId, btnFindPw;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String rootDoc = "schoolInfo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editStudentId = findViewById(R.id.editStudentId); // 학번 입력
        editPassword = findViewById(R.id.editPassword);   // 비밀번호 입력
        btnLogin = findViewById(R.id.btnLogin);
        btnJoin = findViewById(R.id.btnJoin);
        btnFindId = findViewById(R.id.btnFindId);
        btnFindPw = findViewById(R.id.btnFindPw);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String studentId = editStudentId.getText().toString().trim();
                String password = editPassword.getText().toString().trim();

                if (studentId.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "학번과 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }

                db.collection("schoolData").document("schoolInfo")
                        .collection("users").document(studentId)
                        .get()
                        .addOnSuccessListener(document -> {
                            if (!document.exists()) {
                                Toast.makeText(LoginActivity.this, "존재하지 않는 학번입니다.", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            // 학번 존재 → email 필드 읽어서 Auth 로그인
                            String email = document.getString("email");
                            if (email == null || email.isEmpty()) {
                                Toast.makeText(LoginActivity.this, "이메일 정보가 없습니다. 관리자에게 문의하세요.", Toast.LENGTH_SHORT).show();
                                return;
                            }

                            mAuth.signInWithEmailAndPassword(email, password)
                                    .addOnSuccessListener(authResult -> {
                                        Toast.makeText(LoginActivity.this, "로그인 성공!", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                        intent.putExtra("studentId", studentId);
                                        startActivity(intent);
                                        finish();
                                    })
                                    .addOnFailureListener(e -> {
                                        // email은 맞고 비번만 틀린 상황
                                        Toast.makeText(LoginActivity.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                                    });

                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(LoginActivity.this, "네트워크 오류, 다시 시도하세요.", Toast.LENGTH_SHORT).show();
                        });
            }
        });


        btnJoin.setOnClickListener(v -> {
            // 회원가입 화면 이동
            startActivity(new Intent(LoginActivity.this, RegistActivity.class));
        });

        btnFindId.setOnClickListener(v -> {
            // 학번 찾기 화면 이동
            startActivity(new Intent(LoginActivity.this, FindIdActivity.class));
        });

        btnFindPw.setOnClickListener(v -> {
            // 비밀번호 찾기 화면 이동
            startActivity(new Intent(LoginActivity.this, FindPwActivity.class));
        });
    }
}
