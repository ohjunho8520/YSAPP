package com.example.myapplication.main;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class FindPwActivity extends AppCompatActivity {
    private EditText editStudentId, editName, editPhone;
    private Button btnFindPw;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String rootDoc = "schoolInfo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_pw);

        editStudentId = findViewById(R.id.editStudentId);
        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        btnFindPw = findViewById(R.id.btnFindPw);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        btnFindPw.setOnClickListener(v -> {
            String studentId = editStudentId.getText().toString().trim();
            String name = editName.getText().toString().trim();
            String phone = editPhone.getText().toString().trim();

            if (studentId.isEmpty() || name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(FindPwActivity.this, "모든 항목을 입력하세요.", Toast.LENGTH_SHORT).show();
                return;
            }
            db.collection("schoolData").document(rootDoc)
                    .collection("users").document(studentId)
                    .get()
                    .addOnSuccessListener(document -> {
                        if (document.exists() &&
                                name.equals(document.getString("name")) &&
                                phone.equals(document.getString("phone"))) {
                            String email = document.getString("email");
                            if (email == null || email.isEmpty()) {
                                Toast.makeText(FindPwActivity.this, "해당 학번에 등록된 이메일이 없습니다.", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            mAuth.sendPasswordResetEmail(email)
                                    .addOnSuccessListener(unused -> {
                                        Toast.makeText(FindPwActivity.this, "비밀번호 재설정 이메일을 전송했습니다!", Toast.LENGTH_SHORT).show();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(FindPwActivity.this, "이메일 발송 오류", Toast.LENGTH_SHORT).show();
                                    });
                        } else {
                            Toast.makeText(FindPwActivity.this, "정보가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(FindPwActivity.this, "네트워크 오류", Toast.LENGTH_SHORT).show();
                    });
        });
    }
}
