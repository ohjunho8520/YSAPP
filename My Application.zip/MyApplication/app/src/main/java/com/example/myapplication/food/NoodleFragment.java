package com.example.myapplication.food;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;

import java.util.Random;

public class NoodleFragment extends Fragment {

    private Button btnPickMenu;
    private ImageView resultImage;
    private TextView resultText;

    private final String[] menuIds = {
            "noodle_1", "noodle_2", "noodle_3", "noodle_4", "noodle_5", "noodle_6"
    };

    private final String[] menuNames = {
            "계란라면", "냉모밀", "새우튀김냉모밀", "돈까스정식", "돼지고기 김치찌개", "고기전병"
    };

    private final int[] menuImages = {
            R.drawable.fkaus,
            R.drawable.sodahalf,
            R.drawable.todnxnlrla,
            R.drawable.sodahalfehsrktm,
            R.drawable.rlacl,
            R.drawable.rhrl
    };

    public NoodleFragment() {
        super(R.layout.fragment_noodle);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 랜덤 추천 연결
        btnPickMenu = view.findViewById(R.id.btnPickMenu);
        resultImage = view.findViewById(R.id.resultImage);
        resultText = view.findViewById(R.id.resultText);

        btnPickMenu.setOnClickListener(v -> {
            Random random = new Random();
            int index = random.nextInt(menuNames.length);

            RotateAnimation rotate = new RotateAnimation(
                    0, 720,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f);
            rotate.setDuration(1000);
            rotate.setFillAfter(true);
            resultImage.startAnimation(rotate);

            new Handler().postDelayed(() -> {
                resultImage.setImageResource(menuImages[index]);
                resultText.setText("오늘의 추천: " + menuNames[index]);

                resultImage.setVisibility(View.VISIBLE);
                resultText.setVisibility(View.VISIBLE);

                View.OnClickListener goToDetail = vv -> {
                    Intent intent = new Intent(requireContext(), MenuDetailActivity.class);
                    intent.putExtra("menuId", menuIds[index]);
                    intent.putExtra("menuName", menuNames[index]);
                    intent.putExtra("menuImageResId", menuImages[index]);
                    startActivity(intent);
                };
                resultImage.setOnClickListener(goToDetail);
                resultText.setOnClickListener(goToDetail);
            }, 1000);
        });

        // 기존 메뉴 클릭 이벤트 설정
        setupClick(view, R.id.menu_egg_ramen, R.drawable.fkaus);
        setupClick(view, R.id.menu_cold_moemle, R.drawable.sodahalf);
        setupClick(view, R.id.menu_fried_moemle, R.drawable.todnxnlrla);
        setupClick(view, R.id.menu_donkatsu_set, R.drawable.sodahalfehsrktm);
        setupClick(view, R.id.menu_kimchi_goat, R.drawable.rlacl);
        setupClick(view, R.id.menu_meatwarbottle, R.drawable.rhrl);
    }

    private void setupClick(View view, int layoutId, int imageResId) {
        LinearLayout layout = view.findViewById(layoutId);
        if (layout != null) layout.setOnClickListener(v -> {
            String menuId = (String) v.getTag();
            LinearLayout inner = (LinearLayout) ((LinearLayout) v).getChildAt(1);
            String menuName = ((TextView) inner.getChildAt(0)).getText().toString();

            Intent intent = new Intent(requireContext(), MenuDetailActivity.class);
            intent.putExtra("menuId", menuId);
            intent.putExtra("menuName", menuName);
            intent.putExtra("menuImageResId", imageResId);
            startActivity(intent);
        });
    }
}
