package com.example.myapplication.main;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication.R;
import com.example.myapplication.schedule.ScheduleActivity;
import com.example.myapplication.food.MealActivity;
import com.example.myapplication.shuttle.ShuttleActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private TextView textUserInfo;
    private Button btnLogout;
    private ImageView loginIcon;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String studentId; // 로그인에서 전달받는 학번

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Firebase 초기화
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // 뷰 연결
        LinearLayout buttonShuttle = findViewById(R.id.buttonShuttle);
        LinearLayout buttonMeal = findViewById(R.id.buttonMeal);
        LinearLayout buttonSchedule = findViewById(R.id.buttonSchedule); // ← 기존 buttonClub → buttonSchedule 로 수정됨
        loginIcon = findViewById(R.id.loginIcon);
        btnLogout = findViewById(R.id.btnLogout);
        textUserInfo = findViewById(R.id.textUserInfo);

        // 화면 이동 버튼
        buttonShuttle.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ShuttleActivity.class)));
        buttonMeal.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, MealActivity.class)));
        buttonSchedule.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ScheduleActivity.class)));
        // **LoginActivity에서 전달받은 학번 인텐트 받기**
        studentId = getIntent().getStringExtra("studentId");

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            // 로그인 X
            loginIcon.setVisibility(View.VISIBLE);
            btnLogout.setVisibility(View.GONE);
            textUserInfo.setText("로그인을 해주세요");
        } else {
            // 세션이 남아 있으면 DB에서 사용자 정보 불러오기
            db.collection("schoolData").document("schoolInfo")
                    .collection("users")
                    .whereEqualTo("email", currentUser.getEmail())
                    .get()
                    .addOnSuccessListener(qs -> {
                        if (!qs.isEmpty()) {
                            String name = qs.getDocuments().get(0).getString("name");
                            textUserInfo.setText(name + "님 환영합니다!");
                            loginIcon.setVisibility(View.GONE);
                            btnLogout.setVisibility(View.VISIBLE);
                        } else {
                            // 유저 정보 못 찾으면 로그인 필요 안내
                            loginIcon.setVisibility(View.VISIBLE);
                            btnLogout.setVisibility(View.GONE);
                            textUserInfo.setText("로그인을 해주세요");
                        }
                    });
        }


        // 로그인 버튼 클릭
        loginIcon.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        // 로그아웃 버튼 클릭
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            loginIcon.setVisibility(View.VISIBLE);
            btnLogout.setVisibility(View.GONE);
            textUserInfo.setText("로그인을 해주세요");
            // Toast나 Log는 더 이상 안 써도 됨!
        });

        // 인셋 처리
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
}
