package com.example.myapplication.shuttle;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class ShuttleSiheungActivity extends AppCompatActivity {

    private LinearLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shuttle_canvas_siheung);;

        container = findViewById(R.id.shuttleItemContainer);

        addShuttleItem("8:00", "이마트", "시화공단 이마트 건너편 버스정류장");
        addShuttleItem("8:04", "정왕역", "정왕역 2번출구 한우직판장 (4호선)");
        addShuttleItem("8:13", "장곡고교", "장곡고교 앞 동양덱스빌아파트 버스정류장");
        addShuttleItem("8:18", "장곡중학교", "장곡중학교∙대우아파트 버스정류장");
        addShuttleItem("8:25", "시흥능곡역", "장곡고교 앞 동양덱스빌아파트 버스정류장");
        addShuttleItem("8:28", "시흥시청", "시흥시청역 2번출구 건너편 버스정류장");
        addShuttleItem("8:31", "등기소입구", "시흥등기소입구 삼거리");
        addShuttleItem("8:22", "이동", "고속도로 이동");
        addShuttleItem("9:05", "안양역(경유)", "안양역 경유");
        addShuttleItem("9:15", "연성대학교", "연성대학교 정문");
    }



    private void addShuttleItem(String time, String station, String desc) {
        View itemView = LayoutInflater.from(this).inflate(R.layout.item_shuttle, container, false);

        TextView tvTime = itemView.findViewById(R.id.time);
        TextView tvStation = itemView.findViewById(R.id.station);
        TextView tvDesc = itemView.findViewById(R.id.desc);

        tvTime.setText(time);
        tvStation.setText(station);
        tvDesc.setText(desc);

        container.addView(itemView);
    }
}
