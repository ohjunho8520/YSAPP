package com.example.myapplication.food;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.myapplication.R;

import java.util.Random;

public class DonkatsuFragment extends Fragment {

    private Button btnPickMenu;
    private ImageView resultImage;
    private TextView resultText;

    private final String[] menuIds = {
            "a_1", "a_2", "a_3", "a_4", "a_5", "a_6", "a_7", "a_8",
            "a_9", "a_10", "a_11", "a_12", "a_13", "a_14", "a_15", "a_16"
    };

    private final String[] menuNames = {
            "함박카레동", "치킨치즈카레동", "치킨가라아게카레동", "대왕소시지카레동", "오므라이스",
            "카레오므라이스", "함박오므라이스", "닭강정오므라이스", "치킨치즈오므라이스", "대왕소시지오므라이스",
            "치즈김치가츠동", "세종대왕돈까스", "고구마치즈돈까스", "소떡소떡", "닭강정", "치즈시즈닝치킨"
    };

    private final int[] menuImages = {
            R.drawable.a_1, R.drawable.a_2, R.drawable.a_3, R.drawable.a_4,
            R.drawable.a_5, R.drawable.a_6, R.drawable.a_7, R.drawable.a_8,
            R.drawable.a_9, R.drawable.a_10, R.drawable.a_11, R.drawable.a_12,
            R.drawable.a_13, R.drawable.a_14, R.drawable.a_15, R.drawable.a_16
    };

    public DonkatsuFragment() {
        super(R.layout.fragment_donkatsu);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 랜덤 추천 요소 연결
        btnPickMenu = view.findViewById(R.id.btnPickMenu);
        resultImage = view.findViewById(R.id.resultImage);
        resultText = view.findViewById(R.id.resultText);

        btnPickMenu.setOnClickListener(v -> {
            Random random = new Random();
            int index = random.nextInt(menuNames.length);

            // 회전 애니메이션
            RotateAnimation rotate = new RotateAnimation(
                    0, 720,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f);
            rotate.setDuration(1000);
            rotate.setFillAfter(true);
            resultImage.startAnimation(rotate);

            new Handler().postDelayed(() -> {
                resultImage.setImageResource(menuImages[index]);
                resultText.setText("오늘의 추천: " + menuNames[index]);

                resultImage.setVisibility(View.VISIBLE);
                resultText.setVisibility(View.VISIBLE);

                // 이미지나 텍스트 클릭 시 상세 화면으로 이동
                View.OnClickListener goToDetail = vv -> {
                    Intent intent = new Intent(requireContext(), MenuDetailActivity.class);
                    intent.putExtra("menuId", menuIds[index]);
                    intent.putExtra("menuName", menuNames[index]);
                    intent.putExtra("menuImageResId", menuImages[index]);
                    startActivity(intent);
                };
                resultImage.setOnClickListener(goToDetail);
                resultText.setOnClickListener(goToDetail);
            }, 1000);
        });

        // 일반 메뉴 클릭 이벤트 연결
        setupClick(view, R.id.menu_hamburg_curry, "a_1");
        setupClick(view, R.id.menu_chicken_cheese_curry, "a_2");
        setupClick(view, R.id.menu_chicken_karaage_curry, "a_3");
        setupClick(view, R.id.menu_king_sausage_curry, "a_4");
        setupClick(view, R.id.menu_omurice, "a_5");
        setupClick(view, R.id.menu_curry_omurice, "a_6");
        setupClick(view, R.id.menu_hamburg_omurice, "a_7");
        setupClick(view, R.id.menu_chicken_omurice, "a_8");
        setupClick(view, R.id.menu_chkcken_cheese_omurice, "a_9");
        setupClick(view, R.id.menu_king_sausage_omurice, "a_10");
        setupClick(view, R.id.menu_cheese_gimchi_gatsdong, "a_11");
        setupClick(view, R.id.menu_king_donkatsu, "a_12");
        setupClick(view, R.id.menu_go_cheese_donkatsu, "a_13");
        setupClick(view, R.id.menu_cowduk_cowduk, "a_14");
        setupClick(view, R.id.menu_chicken, "a_15");
        setupClick(view, R.id.menu_cheese_chicken, "a_16");
    }

    private void setupClick(View view, int layoutId, String imageName) {
        LinearLayout layout = view.findViewById(layoutId);
        if (layout != null) layout.setOnClickListener(v -> {
            String menuId = (String) v.getTag();
            LinearLayout inner = (LinearLayout) ((LinearLayout) v).getChildAt(1);
            String menuName = ((TextView) inner.getChildAt(0)).getText().toString();

            Intent intent = new Intent(requireContext(), MenuDetailActivity.class);
            intent.putExtra("menuId", menuId);
            intent.putExtra("menuName", menuName);
            intent.putExtra("menuImageResId", getResources().getIdentifier(imageName, "drawable", requireContext().getPackageName()));
            startActivity(intent);
        });
    }
}
