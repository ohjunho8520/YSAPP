package com.example.myapplication.schedule;

import java.util.*;

public class FixedSchedules {
    // 하드코딩된 학사일정 (1월 예시)
    public static final List<UserSchedule> SCHEDULES = Arrays.asList(
            new UserSchedule("all", "성적열람 및 이의신청기간", MyCalendarDay.from(2024,12,30), MyCalendarDay.from(2025,1,3), "#607D8B"),
            new UserSchedule("all", "신정", MyCalendarDay.from(2025,1,1), MyCalendarDay.from(2025,1,1), "#03A9F4"),
            new UserSchedule("all", "업무개시일", MyCalendarDay.from(2025,1,2), MyCalendarDay.from(2025,1,2), "#03A9F4"),
            new UserSchedule("all", "시무식", MyCalendarDay.from(2025,1,3), MyCalendarDay.from(2025,1,3), "#795548"),
            new UserSchedule("all", "동계 계절학기", MyCalendarDay.from(2025,1,6), MyCalendarDay.from(2025,1,17), "#673AB7"),
            new UserSchedule("all", "2학기 성적확정", MyCalendarDay.from(2025,1,7), MyCalendarDay.from(2025,1,7), "#9C27B0"),
            new UserSchedule("all", "전기 졸업유예 접수기간", MyCalendarDay.from(2025,1,8), MyCalendarDay.from(2025,1,15), "#607D8B"),
            new UserSchedule("all", "교직원세미나", MyCalendarDay.from(2025,1,9), MyCalendarDay.from(2025,1,9), "#FF9800"),
            new UserSchedule("all", "국고사업 성과보고 및 환류 워크숍", MyCalendarDay.from(2025,1,10), MyCalendarDay.from(2025,1,10), "#8BC34A"),
            new UserSchedule("all", "동계계절학기 성적입력", MyCalendarDay.from(2025,1,17), MyCalendarDay.from(2025,1,20), "#607D8B"),
            new UserSchedule("all", "동계계절학기 성적열람 및 이의신청", MyCalendarDay.from(2025,1,21), MyCalendarDay.from(2025,1,22), "#607D8B"),
            new UserSchedule("all", "정시 면접/실기고사", MyCalendarDay.from(2025,1,22), MyCalendarDay.from(2025,1,26), "#607D8B"),
            new UserSchedule("all", "임시공휴일", MyCalendarDay.from(2025,1,27), MyCalendarDay.from(2025,1,27), "#03A9F4"),
            new UserSchedule("all", "설날 연휴", MyCalendarDay.from(2025,1,28), MyCalendarDay.from(2025,1,30), "#FF9800"),

            // 2월 일정 (예시)
            new UserSchedule("all", "전기진급 및 졸업사정회", MyCalendarDay.from(2025,2,3), MyCalendarDay.from(2025,2,3), "#607D8B"),
            new UserSchedule("all", "일반휴학·전과·재입학 접수기간", MyCalendarDay.from(2025,2,3), MyCalendarDay.from(2025,2,7), "#607D8B"),
            new UserSchedule("all", "정시 합격자 발표", MyCalendarDay.from(2025,2,6), MyCalendarDay.from(2025,2,6), "#FF9800"),
            new UserSchedule("all", "정시 합격자 등록기간", MyCalendarDay.from(2025,2,10), MyCalendarDay.from(2025,2,12), "#4CAF50"),
            new UserSchedule("all", "복학 접수기간", MyCalendarDay.from(2025,2,10), MyCalendarDay.from(2025,2,14), "#4CAF50"),
            new UserSchedule("all", "재학생(복학생) 수강신청 기간", MyCalendarDay.from(2025,2,10), MyCalendarDay.from(2025,2,18), "#4CAF50"),
            new UserSchedule("all", "제47회 학위수여식", MyCalendarDay.from(2025,2,12), MyCalendarDay.from(2025,2,12), "#9C27B0"),
            new UserSchedule("all", "1학기 재학생 등록기간", MyCalendarDay.from(2025,2,17), MyCalendarDay.from(2025,2,21), "#2196F3"),
            new UserSchedule("all", "입학식", MyCalendarDay.from(2025,2,21), MyCalendarDay.from(2025,2,21), "#03A9F4"),

            // 3월 일정 (예시)
            new UserSchedule("all", "삼일절", MyCalendarDay.from(2025,3,1), MyCalendarDay.from(2025,3,1), "#E91E63"),
            new UserSchedule("all", "대체공휴일", MyCalendarDay.from(2025,3,3), MyCalendarDay.from(2025,3,3), "#03A9F4"),
            new UserSchedule("all", "1학기 개강", MyCalendarDay.from(2025,3,4), MyCalendarDay.from(2025,3,4), "#4CAF50"),
            new UserSchedule("all", "신입생 수강신청기간", MyCalendarDay.from(2025,3,4), MyCalendarDay.from(2025,3,7), "#4CAF50"),
            new UserSchedule("all", "대학생활 적응력 향상 프로그램", MyCalendarDay.from(2025,3,10), MyCalendarDay.from(2025,3,14), "#FFEB3B"),
            new UserSchedule("all", "개교 48주년 기념일", MyCalendarDay.from(2025,3,15), MyCalendarDay.from(2025,3,15), "#8BC34A"),
            new UserSchedule("all", "수업일수 1/4선", MyCalendarDay.from(2025,3,28), MyCalendarDay.from(2025,3,28), "#607D8B"),

            // 4월 일정
            new UserSchedule("all", "중간고사 평가 권장기간", MyCalendarDay.from(2025,4,21), MyCalendarDay.from(2025,5,2), "#FF5722"),
            new UserSchedule("all", "수업일수 2/4선", MyCalendarDay.from(2025,4,24), MyCalendarDay.from(2025,4,24), "#607D8B"),

            // 5월 일정
            new UserSchedule("all", "근로자의날(임시휴업)", MyCalendarDay.from(2025,5,1), MyCalendarDay.from(2025,5,1), "#3F51B5"),
            new UserSchedule("all", "어린이날/부처님오신날", MyCalendarDay.from(2025,5,5), MyCalendarDay.from(2025,5,5), "#03A9F4"),
            new UserSchedule("all", "대체공휴일", MyCalendarDay.from(2025,5,6), MyCalendarDay.from(2025,5,6), "#03A9F4"),
            new UserSchedule("all", "제49회 양지체육대회(자율보강)", MyCalendarDay.from(2025,5,8), MyCalendarDay.from(2025,5,9), "#8BC34A"),
            new UserSchedule("all", "수업일수 3/4선", MyCalendarDay.from(2025,5,26), MyCalendarDay.from(2025,5,26), "#607D8B"),

            // 6월 일정
            new UserSchedule("all", "대통령 선거일", MyCalendarDay.from(2025,6,3), MyCalendarDay.from(2025,6,3), "#2196F3"),
            new UserSchedule("all", "현충일", MyCalendarDay.from(2025,6,6), MyCalendarDay.from(2025,6,6), "#F44336"),
            new UserSchedule("all", "공휴일 보강기간", MyCalendarDay.from(2025,6,10), MyCalendarDay.from(2025,6,13), "#795548"),
            new UserSchedule("all", "기말고사 기간", MyCalendarDay.from(2025,6,16), MyCalendarDay.from(2025,6,20), "#F44336"),
            new UserSchedule("all", "성적입력 기간", MyCalendarDay.from(2025,6,17), MyCalendarDay.from(2025,6,25), "#607D8B"),
            new UserSchedule("all", "수업일수 4/4선", MyCalendarDay.from(2025,6,20), MyCalendarDay.from(2025,6,20), "#607D8B"),
            new UserSchedule("all", "대통령 선거일 보강일", MyCalendarDay.from(2025,6,23), MyCalendarDay.from(2025,6,23), "#2196F3"),
            new UserSchedule("all", "하계방학 시작", MyCalendarDay.from(2025,6,24), MyCalendarDay.from(2025,6,24), "#4CAF50"),
            new UserSchedule("all", "하계 융합학기", MyCalendarDay.from(2025,6,24), MyCalendarDay.from(2025,7,1), "#FFEB3B"),
            new UserSchedule("all", "성적열람 및 이의신청기간", MyCalendarDay.from(2025,6,27), MyCalendarDay.from(2025,7,2), "#607D8B"),

            // 7월 일정
            new UserSchedule("all", "하계 계절학기", MyCalendarDay.from(2025,7,3), MyCalendarDay.from(2025,7,16), "#673AB7"),
            new UserSchedule("all", "교직원세미나", MyCalendarDay.from(2025,7,3), MyCalendarDay.from(2025,7,3), "#FF9800"),
            new UserSchedule("all", "1학기 성적확정/국고사업 성과보고 및 환류 워크숍", MyCalendarDay.from(2025,7,4), MyCalendarDay.from(2025,7,4), "#8BC34A"),
            new UserSchedule("all", "후기 졸업유예 접수기간", MyCalendarDay.from(2025,7,7), MyCalendarDay.from(2025,7,11), "#607D8B"),
            new UserSchedule("all", "진로박람회", MyCalendarDay.from(2025,7,10), MyCalendarDay.from(2025,7,11), "#00BCD4"),
            new UserSchedule("all", "하계 계절학기 성적입력", MyCalendarDay.from(2025,7,16), MyCalendarDay.from(2025,7,17), "#607D8B"),
            new UserSchedule("all", "하계 계절학기 성적열람 및 성적이의신청", MyCalendarDay.from(2025,7,18), MyCalendarDay.from(2025,7,21), "#607D8B"),
            new UserSchedule("all", "하계방학 전체 휴무", MyCalendarDay.from(2025,7,28), MyCalendarDay.from(2025,8,1), "#03A9F4"),

            // 8월 일정
            new UserSchedule("all", "일반휴학·전과·재입학 접수기간", MyCalendarDay.from(2025,8,4), MyCalendarDay.from(2025,8,8), "#607D8B"),
            new UserSchedule("all", "후기 졸업사정회", MyCalendarDay.from(2025,8,6), MyCalendarDay.from(2025,8,6), "#9C27B0"),
            new UserSchedule("all", "복학 접수기간", MyCalendarDay.from(2025,8,11), MyCalendarDay.from(2025,8,14), "#4CAF50"),
            new UserSchedule("all", "재학생(복학생) 수강신청 기간", MyCalendarDay.from(2025,8,11), MyCalendarDay.from(2025,8,19), "#4CAF50"),
            new UserSchedule("all", "광복절", MyCalendarDay.from(2025,8,15), MyCalendarDay.from(2025,8,15), "#F44336"),
            new UserSchedule("all", "2학기 재학생 등록기간", MyCalendarDay.from(2025,8,18), MyCalendarDay.from(2025,8,22), "#2196F3"),
            new UserSchedule("all", "2024학년도 후기 학위수여", MyCalendarDay.from(2025,8,20), MyCalendarDay.from(2025,8,20), "#9C27B0"),

            // 9월 일정
            new UserSchedule("all", "2학기 개강", MyCalendarDay.from(2025,9,1), MyCalendarDay.from(2025,9,1), "#4CAF50"),
            new UserSchedule("all", "2026학년도 수시1차 원서접수기간", MyCalendarDay.from(2025,9,8), MyCalendarDay.from(2025,9,30), "#FFEB3B"),
            new UserSchedule("all", "수업일수 1/4선", MyCalendarDay.from(2025,9,25), MyCalendarDay.from(2025,9,25), "#607D8B"),

            // 10월 일정
            new UserSchedule("all", "개천절", MyCalendarDay.from(2025,10,3), MyCalendarDay.from(2025,10,3), "#E91E63"),
            new UserSchedule("all", "추석연휴", MyCalendarDay.from(2025,10,5), MyCalendarDay.from(2025,10,7), "#FF9800"),
            new UserSchedule("all", "대체공휴일", MyCalendarDay.from(2025,10,8), MyCalendarDay.from(2025,10,8), "#03A9F4"),
            new UserSchedule("all", "한글날", MyCalendarDay.from(2025,10,9), MyCalendarDay.from(2025,10,9), "#FFEB3B"),
            new UserSchedule("all", "임시휴업", MyCalendarDay.from(2025,10,10), MyCalendarDay.from(2025,10,10), "#3F51B5"),
            new UserSchedule("all", "제49회 양지대동제", MyCalendarDay.from(2025,10,16), MyCalendarDay.from(2025,10,17), "#8BC34A"),
            new UserSchedule("all", "2026학년도 수시1차 면접/실기고사", MyCalendarDay.from(2025,10,22), MyCalendarDay.from(2025,10,26), "#FFEB3B"),
            new UserSchedule("all", "중간고사 평가 권장기간", MyCalendarDay.from(2025,10,27), MyCalendarDay.from(2025,11,7), "#FF5722"),
            new UserSchedule("all", "수업일수 2/4선", MyCalendarDay.from(2025,10,30), MyCalendarDay.from(2025,10,30), "#607D8B"),

            // 11월 일정
            new UserSchedule("all", "2026학년도 수시1차 합격자 발표", MyCalendarDay.from(2025,11,4), MyCalendarDay.from(2025,11,4), "#2196F3"),
            new UserSchedule("all", "2026학년도 수시2차 원서접수기간", MyCalendarDay.from(2025,11,7), MyCalendarDay.from(2025,11,21), "#FFEB3B"),
            new UserSchedule("all", "Gem-Festival", MyCalendarDay.from(2025,11,20), MyCalendarDay.from(2025,11,21), "#009688"),
            new UserSchedule("all", "수업일수 3/4선", MyCalendarDay.from(2025,11,26), MyCalendarDay.from(2025,11,26), "#607D8B"),
            new UserSchedule("all", "2026학년도 수시2차 면접/실기고사", MyCalendarDay.from(2025,11,29), MyCalendarDay.from(2025,12,3), "#FFEB3B"),

            // 12월 일정
            new UserSchedule("all", "공휴일 보강기간", MyCalendarDay.from(2025,12,8), MyCalendarDay.from(2025,12,15), "#795548"),
            new UserSchedule("all", "2026학년도 수시2차 합격자 발표", MyCalendarDay.from(2025,12,11), MyCalendarDay.from(2025,12,11), "#2196F3"),
            new UserSchedule("all", "2026학년도 수시 합격자 등록기간", MyCalendarDay.from(2025,12,15), MyCalendarDay.from(2025,12,17), "#4CAF50"),
            new UserSchedule("all", "기말고사 기간", MyCalendarDay.from(2025,12,16), MyCalendarDay.from(2025,12,22), "#F44336"),
            new UserSchedule("all", "성적입력 기간", MyCalendarDay.from(2025,12,17), MyCalendarDay.from(2025,12,26), "#607D8B"),
            new UserSchedule("all", "수업일수 4/4선", MyCalendarDay.from(2025,12,22), MyCalendarDay.from(2025,12,22), "#607D8B"),
            new UserSchedule("all", "동계방학 시작", MyCalendarDay.from(2025,12,23), MyCalendarDay.from(2025,12,23), "#03A9F4"),
            new UserSchedule("all", "동계 융합학기", MyCalendarDay.from(2025,12,23), MyCalendarDay.from(2026,1,2), "#FFEB3B"),
            new UserSchedule("all", "성탄절", MyCalendarDay.from(2025,12,25), MyCalendarDay.from(2025,12,25), "#E91E63"),
            new UserSchedule("all", "2026학년도 정시 원서접수기간", MyCalendarDay.from(2025,12,29), MyCalendarDay.from(2026,1,14), "#FFEB3B"),
            new UserSchedule("all", "성적열람 및 이의신청기간", MyCalendarDay.from(2025,12,30), MyCalendarDay.from(2026,1,5), "#607D8B")


            );

    // 필요하다면 getter로만 제공해도 됨
    public static List<UserSchedule> getSchedules() {
        return SCHEDULES;
    }
}
