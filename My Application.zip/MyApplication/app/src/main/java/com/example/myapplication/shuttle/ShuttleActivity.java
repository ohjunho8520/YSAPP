package com.example.myapplication.shuttle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.example.myapplication.R;

public class ShuttleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shuttle);

        AppCompatButton btnLong1 = findViewById(R.id.btnLong1);
        AppCompatButton btnLong2 = findViewById(R.id.btnLong2);
        AppCompatButton btnLong3 = findViewById(R.id.btnLong3);
        AppCompatButton btnBeomgye = findViewById(R.id.btnBeomgye);
        AppCompatButton btnAnyang = findViewById(R.id.btnAnyang);

        // 장거리 버튼 1 → ShuttleCanvasView
        btnLong1.setOnClickListener(v ->
                startActivity(new Intent(this, ShuttleCanvasView.class)));

        // 장거리 버튼 2 → BumgyeShuttleInfoView
        btnLong2.setOnClickListener(v ->
                startActivity(new Intent(this, ShuttleSiheungActivity.class)));

        // 장거리 버튼 3 → AnyangShuttleTimeTableView
        btnLong3.setOnClickListener(v ->
                startActivity(new Intent(this, ShuttleMokdongActivity.class)));

        // 범계 → BeomgyeShuttleTimeTableView
        btnBeomgye.setOnClickListener(v ->
                startActivity(new Intent(this, BumgyeShuttleInfoView.class)));

        // 안양 → AnyangShuttleInfoView
        btnAnyang.setOnClickListener(v ->
                startActivity(new Intent(this, AnyangShuttleInfoView.class)));
    }
}
