package com.example.myapplication.schedule;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.myapplication.R;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ScheduleActivity extends AppCompatActivity {
    private TextView tvMonth;
    private RecyclerView rvCalendar, rvScheduleList;
    private TextView btnAddSchedule;
    private CalendarAdapter calendarAdapter;
    private ScheduleListAdapter scheduleListAdapter;
    private List<CalendarDate> dateList = new ArrayList<>();
    private List<UserSchedule> userSchedules = new ArrayList<>();
    private List<UserSchedule> selectedDaySchedules = new ArrayList<>();
    private Calendar currentCalendar;
    private FirebaseFirestore db;
    private FirebaseUser user;
    private String userId;
    private MyCalendarDay selectedDay;

    // 하드코딩 학사일정
    private static final List<UserSchedule> fixedSchedules = FixedSchedules.SCHEDULES;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        tvMonth = findViewById(R.id.tvMonth);
        rvCalendar = findViewById(R.id.rvCalendar);
        btnAddSchedule = findViewById(R.id.btnAddSchedule);
        rvScheduleList = findViewById(R.id.rvScheduleList);

        currentCalendar = Calendar.getInstance();
        db = FirebaseFirestore.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        userId = (user != null) ? user.getUid() : null;

        rvCalendar.setLayoutManager(new GridLayoutManager(this, 7));
        calendarAdapter = new CalendarAdapter(dateList, this::onDateClick, userSchedules, fixedSchedules);
        rvCalendar.setAdapter(calendarAdapter);

        rvScheduleList.setLayoutManager(new LinearLayoutManager(this));
        scheduleListAdapter = new ScheduleListAdapter(selectedDaySchedules, new ScheduleListAdapter.OnScheduleActionListener() {
            @Override
            public void onEdit(UserSchedule schedule) {
                Intent intent = new Intent(ScheduleActivity.this, AddScheduleActivity.class);
                intent.putExtra("editSchedule", schedule);
                startActivity(intent);
            }
            @Override
            public void onDelete(UserSchedule schedule) {
                if (schedule.getDocId() != null && !schedule.getUid().equals("all")) {
                    db.collection("schoolData")
                            .document("schoolInfo")
                            .collection("schedule")
                            .document(schedule.getDocId())
                            .delete()
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(ScheduleActivity.this, "삭제 완료", Toast.LENGTH_SHORT).show();
                                loadSchedulesAndRender();
                            });
                }
            }
        });
        rvScheduleList.setAdapter(scheduleListAdapter);

        TextView btnPrev = findViewById(R.id.btnPrev);
        TextView btnNext = findViewById(R.id.btnNext);

        btnPrev.setOnClickListener(v -> changeMonth(-1));
        btnNext.setOnClickListener(v -> changeMonth(1));
        btnAddSchedule.setOnClickListener(v -> {
            Intent intent = new Intent(ScheduleActivity.this, AddScheduleActivity.class);
            startActivity(intent);
        });

        // 로그인 안했으면 +버튼 숨김, 했으면 보이게
        if (user == null) {
            btnAddSchedule.setVisibility(View.GONE);
        } else {
            btnAddSchedule.setVisibility(View.VISIBLE);
        }

        loadSchedulesAndRender();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 로그인상태 체크해서 +버튼 숨김/보임 처리
        user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            btnAddSchedule.setVisibility(View.GONE);
        } else {
            btnAddSchedule.setVisibility(View.VISIBLE);
        }
        loadSchedulesAndRender();
    }

    private void changeMonth(int delta) {
        currentCalendar.add(Calendar.MONTH, delta);
        loadSchedulesAndRender();
    }

    private void loadSchedulesAndRender() {
        userSchedules.clear();
        db.collection("schoolData")
                .document("schoolInfo")
                .collection("schedule")
                .get()
                .addOnSuccessListener(snapshot -> {
                    for (DocumentSnapshot doc : snapshot) {
                        UserSchedule schedule = doc.toObject(UserSchedule.class);
                        if (schedule != null && user != null) {
                            if (schedule.getUid().equals(user.getUid()) || schedule.getUid().equals("all")) {
                                schedule.setDocId(doc.getId());
                                userSchedules.add(schedule);
                            }
                        }
                    }
                    renderCalendar();
                    if (selectedDay != null) updateScheduleList(selectedDay);
                });
    }

    private void renderCalendar() {
        dateList.clear();
        tvMonth.setText(new SimpleDateFormat("yyyy/MM", Locale.getDefault()).format(currentCalendar.getTime()));
        Calendar cal = (Calendar) currentCalendar.clone();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1;
        for (int i = 0; i < firstDayOfWeek; i++) {
            dateList.add(new CalendarDate("", 0, null));
        }
        int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        for (int i = 1; i <= maxDay; i++) {
            MyCalendarDay day = MyCalendarDay.from(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, i);
            int count = 0;
            for (UserSchedule s : fixedSchedules) {
                if (isDateInRange(day, s.getStartDate(), s.getEndDate())) count++;
            }
            for (UserSchedule s : userSchedules) {
                if (isDateInRange(day, s.getStartDate(), s.getEndDate())) count++;
            }
            dateList.add(new CalendarDate(String.valueOf(i), count, day));
        }
        calendarAdapter.notifyDataSetChanged();
    }

    private void onDateClick(String dayStr) {
        if (dayStr.isEmpty()) return;
        int d = Integer.parseInt(dayStr);
        selectedDay = MyCalendarDay.from(currentCalendar.get(Calendar.YEAR), currentCalendar.get(Calendar.MONTH) + 1, d);
        calendarAdapter.setSelectedDay(selectedDay);
        updateScheduleList(selectedDay);
    }

    private void updateScheduleList(MyCalendarDay day) {
        selectedDaySchedules.clear();
        for (UserSchedule s : fixedSchedules) {
            if (isDateInRange(day, s.getStartDate(), s.getEndDate())) selectedDaySchedules.add(s);
        }
        for (UserSchedule s : userSchedules) {
            if (isDateInRange(day, s.getStartDate(), s.getEndDate())) selectedDaySchedules.add(s);
        }
        scheduleListAdapter.notifyDataSetChanged();
    }

    private boolean isDateInRange(MyCalendarDay d, MyCalendarDay start, MyCalendarDay end) {
        if (start == null || end == null || d == null) return false;
        return (!d.isBefore(start) && !d.isAfter(end));
    }
}
