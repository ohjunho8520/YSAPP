package com.example.myapplication.main;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class RegistActivity extends AppCompatActivity {

    private EditText editName, editPhone, editStudentId, editEmailId, editPassword, editPasswordConfirm;
    private Spinner spinnerEmailDomain, spinnerMajor;
    private Button btnRegister;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private String[] emailDomains = {"naver.com", "gmail.com", "daum.net", "hanmail.com"};
    private String[] majors = {"전자공학과", "정보통신과", "전기과", "컴퓨터소프트웨어과",
            "건축과", "실내건축과", "패션디자인비즈니스과", "헤어디자인전공", "메이크업전공", "스킨케어전공",
            "게임콘텐츠과", "웹툰만화콘텐츠과", "영상콘텐츠과", "뉴미디어콘텐츠전공", "시각디자인과", "K-POP과",
            "유통물류과", "경영학과", "세무회계과", "군사학과", "경찰정보보안과",
            "보건의료행정과", "작업치료과", "치기공과", "치위생과", "응급구조과",
            "식품영양학과", "반려동물보건과", "반려동물산업과", "스포츠재활과", "유아특수재활과",
            "사회복지전공", "아동심리보육전공", "사회복지경영과", "유아교육과",
            "항공서비스과", "관광과", "관광영어전공", "관광중국어전공", "호텔관광전공", "호텔외식조리과", "카페베이커리과"}; // 원하는 학과목록으로 교체
    private String rootDoc = "schoolInfo";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);

        editName = findViewById(R.id.editName);
        editPhone = findViewById(R.id.editPhone);
        editStudentId = findViewById(R.id.editStudentId);
        editEmailId = findViewById(R.id.editEmailId);
        spinnerEmailDomain = findViewById(R.id.spinnerEmailDomain);
        editPassword = findViewById(R.id.editPassword);
        editPasswordConfirm = findViewById(R.id.editPasswordConfirm);
        spinnerMajor = findViewById(R.id.spinnerMajor);
        btnRegister = findViewById(R.id.btnRegister);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        ArrayAdapter<String> domainAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, emailDomains);
        domainAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEmailDomain.setAdapter(domainAdapter);

        ArrayAdapter<String> majorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, majors);
        majorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMajor.setAdapter(majorAdapter);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString().trim();
                String phone = editPhone.getText().toString().trim();
                String studentId = editStudentId.getText().toString().trim();
                String emailId = editEmailId.getText().toString().trim();
                String emailDomain = spinnerEmailDomain.getSelectedItem().toString();
                String password = editPassword.getText().toString();
                String passwordConfirm = editPasswordConfirm.getText().toString();
                String major = spinnerMajor.getSelectedItem().toString();

                if (emailDomain.equals("직접입력")) emailDomain = "";
                String email = emailDomain.isEmpty() ? emailId : (emailId + "@" + emailDomain);

                // === [1] 입력값 유효성 검사 ===
                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(studentId)
                        || TextUtils.isEmpty(emailId) || TextUtils.isEmpty(password) || TextUtils.isEmpty(passwordConfirm)) {
                    Toast.makeText(RegistActivity.this, "모든 정보를 입력하세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 학번 8자리
                if (!studentId.matches("\\d{10}")) {
                    Toast.makeText(RegistActivity.this, "학번은 10자리 숫자여야 합니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 비밀번호 8~14자, 숫자, 특수문자
                if (password.length() < 8 || password.length() > 14) {
                    Toast.makeText(RegistActivity.this, "비밀번호는 8~14자여야 합니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!password.matches(".*\\d.*")) {
                    Toast.makeText(RegistActivity.this, "비밀번호에 숫자를 포함해야 합니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!password.matches(".*[!@#$%^&*()_+=\\[\\]{}|;:'\",.<>/?~-].*")) {
                    Toast.makeText(RegistActivity.this, "비밀번호에 특수문자를 포함해야 합니다.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 비밀번호/확인
                if (!password.equals(passwordConfirm)) {
                    Toast.makeText(RegistActivity.this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
                    return;
                }

                // === [2] 중복 검사 체인 호출 ===
                checkStudentId(studentId, () ->
                        checkPhone(phone, () ->
                                checkEmail(email, () ->
                                        createFirebaseUserAndSave(studentId, email, password, name, phone, major)
                                )
                        )
                );
            }
        });
    }

    private void checkStudentId(String studentId, Runnable onSuccess) {
        db.collection("schoolData").document(rootDoc)
                .collection("users").document(studentId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        Toast.makeText(this, "이미 등록된 학번입니다.", Toast.LENGTH_SHORT).show();
                    } else {
                        onSuccess.run();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "네트워크 오류: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void checkPhone(String phone, Runnable onSuccess) {
        db.collection("schoolData").document(rootDoc)
                .collection("users")
                .whereEqualTo("phone", phone)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    if (!querySnapshot.isEmpty()) {
                        Toast.makeText(this, "이미 등록된 전화번호입니다.", Toast.LENGTH_SHORT).show();
                    } else {
                        onSuccess.run();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "네트워크 오류: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void checkEmail(String email, Runnable onSuccess) {
        db.collection("schoolData").document(rootDoc)
                .collection("users")
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    if (!querySnapshot.isEmpty()) {
                        Toast.makeText(this, "이미 등록된 이메일입니다.", Toast.LENGTH_SHORT).show();
                    } else {
                        onSuccess.run();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "네트워크 오류: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void createFirebaseUserAndSave(String studentId, String email, String password,
                                           String name, String phone, String major) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Map<String, Object> userMap = new HashMap<>();
                        userMap.put("name", name);
                        userMap.put("phone", phone);
                        userMap.put("email", email);
                        userMap.put("major", major);
                        userMap.put("studentId", studentId);

                        db.collection("schoolData").document(rootDoc)
                                .collection("users").document(studentId)
                                .set(userMap)
                                .addOnSuccessListener(aVoid -> {
                                    Toast.makeText(this, "회원가입이 완료되었습니다!", Toast.LENGTH_SHORT).show();
                                    finish();
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(this, "Firestore 저장 오류: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        Toast.makeText(this, "이미 등록된 이메일이거나 형식 오류입니다.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}